// Adding the modules which are needed to perform the simulation
#include "tutorial-app.h"                    
#include "ns3/applications-module.h"           
#include "ns3/core-module.h"                   
#include "ns3/internet-module.h"               
#include "ns3/network-module.h"                
#include "ns3/point-to-point-module.h"                            
#include "ns3/mobility-module.h"               
#include "ns3/wifi-module.h"                
#include "ns3/yans-wifi-helper.h"              
#include "ns3/ssid.h"  
#include "ns3/flow-monitor-module.h"                        
#include <fstream>     

// using the ns3 namespace
using namespace ns3;

// setting the logging component
NS_LOG_COMPONENT_DEFINE("ProjectSimulationScript");

// ===========================================================================
//  Network Topology:
//
//  Node1 --- [p2p] --- Switch1 --- [p2p] --- AP1 ~~~[wifi]~~~ Node2
//  10.10.10.9          (node                10.10.10.6       10.10.10.10
//
//  - Node1  : Wired to the switch, it will send to packets to Node2
//  - Switch1: Switch which connects Node1 and AP1
//   - AP1    : Access Point which connects to Node2             
//  - Node2  : Node2 wirelessly connected to AP1, will recieve the packets from Node1 and will move around in the topology
// ===========================================================================
//
/**
 * Congestion window change callback
 *
 * @param oldCwnd Old congestion window.
 * @param newCwnd New congestion window.
 */
 // Function that outputs the congestion size
    static void
    CwndChange(uint32_t oldCwnd, uint32_t newCwnd)
    {
        NS_LOG_UNCOND(Simulator::Now().GetSeconds() << "\t" << newCwnd);
    }

int
main(int argc, char* argv[])
{
    double simTime = 120.0;
	CommandLine cmd(__FILE__);
	cmd.AddValue("simTime", "Duration of simulation in seconds", simTime);
	cmd.Parse(argc, argv);

    // Setting the TCP-algoritm to be used
    Config::SetDefault("ns3::TcpL4Protocol::SocketType", StringValue("ns3::TcpHybla")); //StringValue("ns3::TcpVegas")); //StringValue("ns3::TcpVeno")); //StringValue("ns3::TcpHybla"));
	
	// tcp socket settings
	 Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue(4194304));
     Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue(4194304));


    // Creating the nodes for the point-to-point links: Node1, Switch1 and AP1
    NodeContainer p2pNodes;
    p2pNodes.Create(3);

    // Creating AP1
    NodeContainer wifiApNode = p2pNodes.Get(2);

    // Creating Node2
    NodeContainer wifiStaNode;   
    wifiStaNode.Create(1);

    // Setting the link speed and delay for the links: Node1->Switch1 and Switch1->AP1
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("1000Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("2ms"));

    // Setting up the link between Node1 and Switch1
    NetDeviceContainer linkNode1Switch1;
    linkNode1Switch1 = p2p.Install(p2pNodes.Get(0), p2pNodes.Get(1));

    // Setting up the link between Switch1 and AP1
    NetDeviceContainer linkSwitch1Ap1;
    linkSwitch1Ap1 = p2p.Install(p2pNodes.Get(1), p2pNodes.Get(2));

    // Configuring the channel helper for the and wireless channel
    YansWifiChannelHelper channel;
    // This model is necessary because of the fact that Node2 moves around
    channel.AddPropagationLoss("ns3::LogDistancePropagationLossModel", "Exponent", DoubleValue(3.5));
	channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");

    // Configuring the channel helper for the physical link
    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());
    phy.SetErrorRateModel("ns3::NistErrorRateModel");

    // Setting up the mac layer using ns-3 dafaults 
    WifiMacHelper mac;
    Ssid ssid = Ssid("ns-3-ssid");

    //setting the wi-fi standard, uses 802.11ax (known commercially as Wi-Fi 6) as default
    WifiHelper wifi;
	wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",    StringValue("HeMcs2"),
                                 "ControlMode", StringValue("HeMcs2"));

    // Install wi-fi on Node2 with the set up configuration for the wi-fi model
    mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid), "ActiveProbing", BooleanValue(false));
    NetDeviceContainer staDevices;
    staDevices = wifi.Install(phy, mac, wifiStaNode);

    // Intsall wi-fi on AP1 with the set up configuration for the wi-fi model
    mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));
    NetDeviceContainer apDevices;
    apDevices = wifi.Install(phy, mac, wifiApNode);

    // The mobility model configuration for AP1 setting it to a fixed position
    MobilityHelper mobility;
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(wifiApNode);

    // The mobility model to poistion and move around Node2
    mobility.SetMobilityModel("ns3::WaypointMobilityModel");
     Ptr<WaypointMobilityModel> waypointModel;
    mobility.Install(wifiStaNode);

    // The positions to move to and the time when it moves
	 waypointModel = DynamicCast<WaypointMobilityModel>(wifiStaNode.Get(0)->GetObject<MobilityModel>());
    waypointModel->AddWaypoint(Waypoint(Seconds(0),    Vector(2,  0, 0)));   // starting at 2m form AP1
    waypointModel->AddWaypoint(Waypoint(Seconds(40),   Vector(2,  0, 0)));   // After 20s start moving to 2nd position
    waypointModel->AddWaypoint(Waypoint(Seconds(50),   Vector(10, 0, 0)));   // 5 seconds in transit to move to the 2nd position (10m from AP1)
    waypointModel->AddWaypoint(Waypoint(Seconds(80),   Vector(10, 0, 0)));   // Standing still for 15 seconds at second position
    waypointModel->AddWaypoint(Waypoint(Seconds(90),   Vector(20, 0, 0)));   // 5 seconds in transit to move to the 3rd position (18m from AP1)
    waypointModel->AddWaypoint(Waypoint(Seconds(120),  Vector(20, 0, 0)));   // standing still at 18m from AP1 till the simulation is over

    // Setup for the IP-adressing, dissabeling IPv6
    InternetStackHelper stack;
    stack.SetIpv6StackInstall(false);
    stack.Install(p2pNodes);
    stack.Install(wifiStaNode);

    // Setting up the network for the link Node1->Switch1
    Ipv4AddressHelper address;
    address.SetBase("10.10.10.0", "255.255.255.252");
    Ipv4InterfaceContainer link1Interfaces = address.Assign(linkNode1Switch1);

    // Setting up the network for the link Switch1->AP1
    address.SetBase("10.10.10.4", "255.255.255.252");
    Ipv4InterfaceContainer link2Interfaces = address.Assign(linkSwitch1Ap1);

    // Setting up the network for the link AP1->Node2
    address.SetBase("10.10.10.8", "255.255.255.252");
    Ipv4InterfaceContainer wifiInterfaces = address.Assign(staDevices);
    address.Assign(apDevices);

    // allowing for routing over different subnets
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // Setting up the port where Node2 will recieve its packets
    uint16_t sinkPort = 8080;

    // Setting up the IP adres of Node2 as the recieving adres
    Address sinkAddress(InetSocketAddress(wifiInterfaces.GetAddress(0), sinkPort));
    PacketSinkHelper packetSinkHelper("ns3::TcpSocketFactory",
                                      InetSocketAddress(Ipv4Address::GetAny(), sinkPort));
    ApplicationContainer sinkApps = packetSinkHelper.Install(wifiStaNode.Get(0));
    sinkApps.Start(Seconds(0.));     
    sinkApps.Stop(Seconds(simTime));

    // Setting up Node1 to be able to send packets
    Ptr<Socket> ns3TcpSocket = Socket::CreateSocket(p2pNodes.Get(0), TcpSocketFactory::GetTypeId());
    ns3TcpSocket->TraceConnectWithoutContext("CongestionWindow", MakeCallback(&CwndChange));

    // Configuring the sending application and setting it on Node1
    Ptr<TutorialApp> app = CreateObject<TutorialApp>();
    app->Setup(ns3TcpSocket, sinkAddress, 1040, 4294967295, DataRate("700Mbps"));
    p2pNodes.Get(0)->AddApplication(app);
    app->SetStartTime(Seconds(1.));
    app->SetStopTime(Seconds(simTime));

    // Running the simulator
	Simulator::Stop(Seconds(simTime));
    Simulator::Run();
    Simulator::Destroy();

    return 0;

}